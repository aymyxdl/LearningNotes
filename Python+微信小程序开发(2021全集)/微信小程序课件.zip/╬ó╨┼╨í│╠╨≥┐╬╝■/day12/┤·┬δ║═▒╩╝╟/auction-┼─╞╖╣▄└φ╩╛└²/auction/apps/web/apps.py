from django.apps import AppConfig


class WebConfig(AppConfig):
    name = 'apps.web'
