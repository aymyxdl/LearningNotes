#!/usr/bin/env python
# -*- coding:utf-8 -*-
import s1

# s1.x1.delay(3, 4)
# print(dir(s1.app1))
# print(dir(s1.app2))
# print(s1.app1.tasks.keys())
# s1.app1.tasks.get('s1.x1').delay(1, 2)
# s1.app2.tasks.get('s1.x1').delay(2, 2)

s1.x1.delay(3, 4)
