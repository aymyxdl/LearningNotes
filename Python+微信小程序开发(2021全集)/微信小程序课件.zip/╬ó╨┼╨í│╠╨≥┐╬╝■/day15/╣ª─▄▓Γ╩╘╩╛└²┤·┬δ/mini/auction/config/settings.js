module.exports = {
  loginPage: "/pages/login/login"
}