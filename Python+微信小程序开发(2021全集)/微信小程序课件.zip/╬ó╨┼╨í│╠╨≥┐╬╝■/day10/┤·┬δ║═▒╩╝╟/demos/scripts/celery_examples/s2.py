from s1 import x1


result = x1.delay(1, 4)
print(result.id)